﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.PostProcessing;
using System.IO;

public class PostProfileV12Json : ScriptableWizard {
    public PostProcessingProfile postProcessingProfile;
    public string levelName = "LevelName";
    [MenuItem("Tools/PostProfile V1 To Json")]
    static void InitWindow()
    {
        GetWindow(typeof(PostProfileV12Json)).Show();
    }
    static readonly string CustomPostProcessingProfileName = "postprofile.bytes";
    static readonly string CustomPostProcessingProfilePath = "Custom/PostProcessing";
    void OnWizardCreate()
    {
        if (!postProcessingProfile)
        {
            Debug.Log("<b>[PostProfile V1 To Json]</b> <color=red>Reference a profile first then try again!</color>");
            return;
        }

        string serializedData = JsonUtility.ToJson(postProcessingProfile, true);
        string path = string.Format("{0}/{1}/{2}/", Application.dataPath, CustomPostProcessingProfilePath, levelName);
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string writePath = path + CustomPostProcessingProfileName;
        File.WriteAllText(writePath, serializedData);
        AssetDatabase.Refresh();
        Debug.Log("Write Path: " + writePath);
    }
}
